# 麻雀 役フラッシュ — Androidアプリ版

これはブラウザ/PWAではなく、Android端末に通常のアプリとしてインストールするための
ネイティブAndroidプロジェクトです。

## 特徴
- 完全オフライン動作
- 通信権限（INTERNET permission）なし
- 問題・解説・牌画像はAPK内に格納
- 単独役 / 複合役 / 役一覧 / 用語をそのまま収録
- アプリアイコンあり
- WebViewでローカルHTMLを表示するため、これまで作った学習ロジックを維持

## Android StudioでAPKを作る
1. Android Studioでこのフォルダを開く
2. Gradle Syncを完了
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. app/build/outputs/apk/debug/app-debug.apk をAndroid端末へ入れてインストール

## GitHub ActionsでAPKを自動生成
このフォルダをGitHubリポジトリに置くと `.github/workflows/build-apk.yml` が自動実行されます。
Actionsの実行結果にある `mahjong-yaku-flash-apk` をダウンロードすると、
インストール可能な debug APK が入っています。

## パッケージ名
jp.yakuflash.mahjong

## バージョン
1.0.0
